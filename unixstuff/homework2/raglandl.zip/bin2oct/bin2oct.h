#ifndef _BIN2OCT_H
#define _BIN2OCT_H
#endif

/**
 * @file
 * Header file that declares the bin2oct function
 */

unsigned int bin2oct(const char *binary);
